import React from 'react';
import '../footer.css';
function FooterComponent() {

  return(
<>
	<div className="copyright ">
		<div className="container-fluid text-center">
					<p>Copyrights &copy; 2023 - All Rights Reserved.<br></br>
					</p>

		</div>
	</div>


  </>
  );
}


export default FooterComponent;
